function startGame() {
    // Redireciona para a fase 1 do jogo
    window.location.href = 'Fase I/fase1.html';
}
